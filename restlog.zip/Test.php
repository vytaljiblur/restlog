<?php
/**
 * Created by JetBrains PhpStorm.
 * User: vitaliji
 * Date: 18/07/13
 * Time: 10:33
 * To change this template use File | Settings | File Templates.
 */

class Test extends PHPUnit_Framework_TestCase {

}
